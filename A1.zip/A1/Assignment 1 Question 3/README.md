**Program Instructions**  

Sample Command Line Use
```Bash
python webcrawler3.py initialURL
```
**Put all URLs in quotes to avoid OS errors**  
Example Execution
```Bash
python webcrawler3.py "https://uwaterloo.ca/canadian-index-wellbeing/"
```