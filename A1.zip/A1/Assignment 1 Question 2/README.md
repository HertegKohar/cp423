**Program Instructions**  

Sample Command Line Use
```Bash
python webcrawler2.py [-h] researcherURL
```
**Put all URLs in quotes to avoid OS errors**  
Example Execution
```Bash
python webcrawler2.py "https://scholar.google.ca/citations?user=86V0RSQAAAAJ&hl=en&oi=ao"
```
